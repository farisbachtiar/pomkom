package operator.penugasan;

public class Example1 {
    double c = rumus1();
    
    double rumus1(){
        double x = 1*5;
        return x;
    }
}
