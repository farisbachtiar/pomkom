package abstraction;


public class DataManajer extends CRUD{

    @Override
    public void createData() {
        
    }

    @Override
    public void readData() {
        
    }

    @Override
    public void updateData() {
        
    }

    @Override
    public void deleteData() {
        
    }
    
}
