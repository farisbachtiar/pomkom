package abstraction;

public class Buaya extends Hewan{

    @Override
    public void suaraHewan() {
        System.out.println("BBBBB");
    }
    
}
