package abstraction;


public class Kucing extends Hewan{

    @Override
    public void suaraHewan() {
        System.out.println("Meong");
    }
    
}
