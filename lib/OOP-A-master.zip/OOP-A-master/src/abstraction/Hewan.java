package abstraction;

abstract class Hewan {
    public abstract void suaraHewan();
}
